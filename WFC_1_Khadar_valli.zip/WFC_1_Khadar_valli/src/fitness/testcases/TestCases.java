package fitness.testcases;
import java.util.ArrayList;

import fitness.club.Booking;
import fitness.club.Customer;
import fitness.club.ViewTimeTable;
import junit.framework.TestCase;

public class TestCases extends TestCase{

	 Customer cust;
	 ViewTimeTable viewTT;
	 ArrayList<ViewTimeTable> viewAL;
	 ArrayList<Booking> bookingAL;
	 Booking bookObj;

	protected void setUp() throws Exception {
		cust = new Customer();
		viewTT = new ViewTimeTable();
		bookObj = new Booking();
		viewAL = new ArrayList<ViewTimeTable>();
		bookingAL = new ArrayList<Booking>();
		viewAL= ViewTimeTable.readTimeTableFile();
		bookingAL=Booking.readBookingFile();
	}

	protected void tearDown() {
		// release objects under test here, if necessary
	}
		
	public void testdisplayCustomer() {
		int i;
		try {
			i = cust.displayCustomer();
			assertEquals(10, i);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  void testViewTimeTableByFitness() {
		int i=viewTT.viewTimeTableByFitnessType("Yoga", viewAL);
		assertEquals(8, i);
	}
	
	public  void testViewTimeTable() {
		int i=viewTT.viewTimeTableByDayName("Sunday", viewAL);
		assertEquals(16, i);
	}
	
	public  void testBookingAdd() {
		boolean check;
		try {
			check = bookObj.bookingFitnessLesson("1004", "23-04-2023", "Sunday", "Boxfit",viewAL,bookingAL);
			assertEquals(true, check);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		public  void testBookingCancel() {
			boolean check;
			try {
				check = bookObj.cancelYourBooking("1004", "23-04-2023", "Sunday", "Boxfit",viewAL,bookingAL);
				assertEquals(true, check);
			} catch (Exception ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}	
		
	}
	
	

}

