package fitness.club;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class ViewTimeTable {
	int id, count;
	String date, day, type;
	double price;
	BufferedReader br;
	FileReader fr;
	
	public ViewTimeTable() {

	}
	public ViewTimeTable(int id,String date,String day, String type,double price,int count){
		this.id=id;
		this.date=date;
		this.day=day;
		this.type=type;
		this.price=price;
		this.count=count;
	}
	
	public static ArrayList<ViewTimeTable> readTimeTableFile() throws Exception {
		String timeTable;
		BufferedReader br;
		FileReader fr;
		ArrayList<ViewTimeTable> viewAL = new ArrayList<ViewTimeTable>();
		
		fr = new FileReader("./data/timetable.txt");
		br = new BufferedReader(fr);
		while((timeTable=br.readLine())!=null){
			String []tt=timeTable.split(",");
			ViewTimeTable vtt=new ViewTimeTable(Integer.parseInt(tt[0]),tt[1],tt[2],tt[3],Double.parseDouble(tt[4].trim()),Integer.parseInt(tt[5]));
			viewAL.add(vtt);
		}
		fr.close();
		return viewAL;
	}
		
	public void setId(int id)
	{
		this.id = id;
	}
	
	public int getId()
	{
		return id;
	}
	
	public void setDate(String date)
	{
		this.date = date;
	}
	
	public String getDate()
	{
		return date;
	}
	
	public void setDay(String day)
	{
		this.day = day;
	}
	
	public String getDay()
	{
		return day;
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
	
	public String getType()
	{
		return type;
	}
	
	public void setPrice(double price) {
		this.price=price;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setCount(int count)
	{
		this.count = count;
	}
	
	public int getCount()
	{
		return count;
	}
	
	public String toString()
	{
		return id+","+date+","+day+","+type+","+price+","+count;
	}
	
	public int viewTimeTableByDayName(String dayName, ArrayList<ViewTimeTable> viewAL)
	{
		int count=0;
		System.out.println("\n\n\nTime Table");
		System.out.println("=============================================");
		System.out.println("ID\tDate\tDay\tType\tPrice\tCount");
		System.out.println("=============================================");
		for(int i=0;i<viewAL.size();i++)
		{
			if (viewAL.get(i).getDay().equalsIgnoreCase(dayName)) {
				System.out.println(viewAL.get(i).getId()+" "+viewAL.get(i).getDate().toString()+" "+viewAL.get(i).getDay()+" "+viewAL.get(i).getType()+" "+viewAL.get(i).getPrice()+" "+viewAL.get(i).getCount());
				count=count+1;
			}
		}
		
		System.out.println("=============================================");
		return count;
	}
	
	public int viewTimeTableByFitnessType(String fitnessType, ArrayList<ViewTimeTable> viewAL)
	{
		int count=0;
		System.out.println("\n\n\nTime Table");
		System.out.println("=============================================");
		System.out.println("ID\tDate\tDay\tType\tPrice\tCount");
		System.out.println("=============================================");
		for(int i=0;i<viewAL.size();i++)
		{
			if (viewAL.get(i).getType().equalsIgnoreCase(fitnessType)) {
				System.out.println(viewAL.get(i).getId()+" "+viewAL.get(i).getDate().toString()+" "+viewAL.get(i).getDay()+" "+viewAL.get(i).getType()+" "+viewAL.get(i).getPrice()+" "+viewAL.get(i).getCount());
				count=count+1;
			}
		}
		
		System.out.println("=============================================");
		return count;
	}
}
