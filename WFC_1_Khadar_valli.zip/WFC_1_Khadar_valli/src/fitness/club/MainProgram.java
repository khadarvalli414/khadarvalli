package fitness.club;

import java.util.*;

public class MainProgram {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception
	{
		int choice = -1;
		
		Scanner s = new Scanner(System.in);
		Scanner s1 = new Scanner(System.in);
		
		Customer cust = new Customer();
		ViewTimeTable viewTT = new ViewTimeTable();
		Booking bookObj = new Booking();
		
		ArrayList<ViewTimeTable> viewAL = new ArrayList<ViewTimeTable>();
		ArrayList<Booking> bookingAL = new ArrayList<Booking>();

		String cId, bDate,bDay,bType,bDate1,bDay1,bType1, bReview ;
		int bRate;

		viewAL= ViewTimeTable.readTimeTableFile();
		bookingAL=Booking.readBookingFile();
		
		do
		{
			new MainMenu();
			System.out.print("Enter your choice : ");
			choice = s.nextInt();
			
			switch(choice){
				case 1: //Case 1 for Add Customer
					cust.addCustomer();
					break;
					
				case 2: // Case 2 for Display Customer
					cust.displayCustomer();
					break;

				case 3: // Case 3 for View Time Table by Day Name
					System.out.println("\n\n\nView Time Table by Day Name");
					System.out.print("\nEnter Day name only (Saturday or Sunday) : ");
					String sDay = s1.nextLine();
					viewTT.viewTimeTableByDayName(sDay, viewAL);
					break;

				case 4: // Case 4 for View Time Table by Fitness Type
					System.out.println("\n\n\nView Time Table by Fitness Type");
					System.out.print("\nEnter Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					String sType = s1.nextLine();
					viewTT.viewTimeTableByFitnessType(sType, viewAL);
					break;
				
				case 5: // Case 5 Booking a Fitness Lesson
					System.out.print("\n\nBook Your Fitness Lesson");
					System.out.print("\n\nEnter Customer Id : ");
					cId = s1.nextLine();
					System.out.print("\n\nEnter Date only (dd-mm-yyyy) : ");
					bDate = s1.nextLine();
					System.out.print("\n\nEnter Day name only (Saturday or Sunday) : ");
					bDay = s1.nextLine();
					System.out.print("\n\nEnter Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					bType = s1.nextLine();
					bookObj.bookingFitnessLesson(cId, bDate, bDay, bType, viewAL, bookingAL);
					break;
					
				case 6: // Case 6 Change Your Booking Fitness Lesson
					System.out.print("\n\n\nChange Your Booking");
					System.out.print("\n\nEnter Customer Id : ");
					cId = s1.nextLine();
					System.out.print("\n\nEnter Old Date only (dd-mm-yyyy) : ");
					bDate = s1.nextLine();
					System.out.print("\n\nEnter Old Day name only (Saturday or Sunday) : ");
					bDay = s1.nextLine();
					System.out.print("\n\nEnter Old Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					bType = s1.nextLine();
					
					System.out.print("\n\nEnter New Date only (dd-mm-yyyy) : ");
					bDate1 = s1.nextLine();
					System.out.print("\n\nEnter New Day name only (Saturday or Sunday) : ");
					bDay1 = s1.nextLine();
					System.out.print("\n\nEnter New Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					bType1 = s1.nextLine();
					bookObj.changeYourBooking(cId, bDate, bDay, bType, bDate1, bDay1, bType1, viewAL, bookingAL);				
					break;					
					
				case 7: // Cancel Your Booking
					System.out.println("\n\n\nCancel Your Booking");
					System.out.print("\n\nEnter Customer Id : ");
					cId = s1.nextLine();
					System.out.print("\n\nEnter Date only (dd-mm-yyyy) : ");
					bDate = s1.nextLine();
					System.out.print("\n\nEnter Day name only (Saturday or Sunday) : ");
					bDay = s1.nextLine();
					System.out.print("\n\nEnter Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					bType = s1.nextLine();
					bookObj.cancelYourBooking(cId, bDate, bDay, bType, viewAL, bookingAL);
					break;
				
				case 8: // Attend Your Booking Lesson
					System.out.println("Attend a Booking");
					System.out.print("\nEnter Customer Id : ");
					cId = s1.nextLine();
					System.out.print("\n\n\nEnter Date only (dd-mm-yyyy) : ");
					bDate = s1.nextLine();
					System.out.print("\n\n\nEnter Day name only (Saturday or Sunday) : ");
					bDay = s1.nextLine();
					System.out.print("\n\n\nEnter Fitness Type (Yoga, Spin, Boxfit, Zumba) : ");
					bType = s1.nextLine();
					System.out.print("\n\n\nEnter Yout Review : ");
					bReview = s1.nextLine();
					System.out.print("\n\n\nEnter Rating (1: Very dissatisfied, 2: Dissatisfied, 3: Ok, 4: Satisfied, 5: Very Satisfied): ");
					bRate = s1.nextInt();
					bookObj.attendYourBooking(cId, bDate, bDay, bType, bReview, bRate, bookingAL);
					break;					
									  	
				case 9: // Monthly Lesson Report
					bookObj.monthlyLessonReport(bookingAL);
					break;
					
				case 10: // Monthly champion fitness type report
					System.out.print("\n\n\nEnter Month Number (1-12) : ");
					int month=s1.nextInt();
					bookObj.monthlyChampionReport(month, bookingAL);
					break;
					
				case 0:
					System.exit(0);
					break;
			}
		}while(choice!=0);
	}
}
