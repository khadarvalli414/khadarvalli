package fitness.club;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;


public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;
	String customerId;
	String customerName;
	int customerAge;
	String mobileNo;
	FileWriter fw;
	FileReader fr;
	BufferedReader br;
	Scanner s = new Scanner(System.in);
	Scanner s1 = new Scanner(System.in);
	ArrayList<Customer> custAL = new ArrayList<Customer>();
	
	public Customer()
	{
		
	}
	
	Customer(String customerId, String customerName, int customerAge, String mobileNo)
	{
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAge = customerAge;
		this.mobileNo = mobileNo;
	}
	
	public String toString()
	{
		return customerId+","+customerName+","+customerAge+","+mobileNo;
	}
	
	public void setCustomerId(String customerId)
	{
		this.customerId = customerId;
	}
	
	public String getCustomerId()
	{
		return customerId;
	}
	
	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}
	
	public String getCustomerName()
	{
		return customerName;
	}
	
	public void setCustomerAge(int customerAge)
	{
		this.customerAge = customerAge;
	}
	
	public int getCustomerAge()
	{
		return customerAge;
	}
	
	public void setMobileNo(String mobileNo)
	{
		this.mobileNo = mobileNo;
	}
	
	public String getMobileNo()
	{
		return mobileNo;
	}
	
	public int addCustomer() throws Exception
	{
		fw = new FileWriter("./data/customer.txt", true);
		System.out.print("\nEnter how many customer : ");
		int no = s.nextInt();
		for(int i=0; i<no; i++)
		{
			System.out.print("\nEnter Customer Id : ");
			String id = s1.nextLine();
			
			System.out.print("\nEnter Customer Name : ");
			String name = s1.nextLine();
			
			System.out.print("\nEnter Customer Age : ");
			int age = s.nextInt();
			
			System.out.print("\nEnter Customer Mobile No. : ");
			String mobile = s1.nextLine();
			Customer cust=new Customer(id, name, age, mobile);
			custAL.add(cust);
			fw.write(cust.toString()+System.getProperty("line.separator"));
		}
		fw.close();
		return no;
	}
	
	public int displayCustomer() throws Exception
	{
		int count=0;
		fr = new FileReader("./data/customer.txt");
		br = new BufferedReader(fr);
		String line;
		System.out.println("\n\n\nAll Customer Details");
		System.out.println("=============================================");
		System.out.println("ID\tName\tAge\tMobile No.");
		System.out.println("=============================================");
		while((line=br.readLine())!=null)
		{
			System.out.println(line);
			count=count+1;
		}
		System.out.println("=============================================");
		return count;
	}

}
