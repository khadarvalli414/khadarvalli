// User Define Package Name
package fitness.club;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class Booking {
	String custId, date, day, type, status, review;
	int ttid, ttId1, rating, ttId, loc, loc1, bookLoc;
	boolean check, canBook, canChange, canCancel, canAttend;
	double price, price1;
	
	
	FileWriter bookfw;
	ArrayList<ViewTimeTable> viewAL = new ArrayList<ViewTimeTable>();
	
	public Booking() throws Exception
	{
		check=false;
		canBook=false;
		canCancel=false;
		canChange=false;
		canAttend=false;
		ttId=0;
		ttId1 = 0;
		loc=0;
		loc1=0;
		
	}
	
	public Booking(int ttid, String custId, String date, String day, String type,double price, int rating, String status,String review)
	{
		this.ttid = ttid;
		this.custId = custId;
		this.date = date;
		this.day=day;
		this.type = type;
		this.price=price;
		this.rating = rating;
		this.status = status;
		this.review=review;
	}
	
	public static ArrayList<Booking> readBookingFile() throws Exception, IOException {
		FileReader fr;
		BufferedReader br;
		ArrayList<Booking> bookingAL = new ArrayList<Booking>();

		File bookFile=new File("./data/booking.txt");
		if (bookFile.exists()) {
			fr = new FileReader(bookFile);
			br = new BufferedReader(fr);
			String booking;
			while((booking=br.readLine())!=null)
			{
				String []bk=booking.split(",");
				if (bk[0].equals(""))
				    break;
				Booking book=new Booking(Integer.parseInt(bk[0]),bk[1],bk[2],bk[3],bk[4],Double.parseDouble(bk[5]),Integer.parseInt(bk[6]),bk[7],bk[8]);
				bookingAL.add(book);
			}
		}
		return bookingAL;
	}
	
	public void setBookId(int ttid)
	{
		this.ttid = ttid;
	}
	public int getBookId()
	{
		return ttid;
	}
	
	public void setCustId(String custId)
	{
		this.custId = custId;
	}
	public String getCustId()
	{
		return custId;
	}
	
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getDate()
	{
		return date;
	}
	
	public void setDay(String day)
	{
		this.day = day;
	}
	public String getDay()
	{
		return day;
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
	public String getType()
	{
		return type;
	}
	
	public void setPrice(double price) {
		this.price=price;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setRating(int rating)
	{
		this.rating = rating;
	}
	public int getRating()
	{
		return rating;
	}
	
	public void setStatus(String status)
	{
		this.status = status;
	}
	public String getStatus()
	{
		return status;
	}

	public void setReview(String review)
	{
		this.review = review;
	}
	public String getReview()
	{
		return review;
	}

	public String toString() {
		return ttid+","+custId+","+date+","+day+","+type+","+price+","+rating+","+status+","+review;
	}
	
	public static void writeTimeTableFile(String fileName,ArrayList<ViewTimeTable> viewAL) throws IOException {
	    FileWriter fwr = null;
	    try {
	        fwr = new FileWriter(fileName);
	        for(int i=0;i<viewAL.size();i++) {
	          fwr.write(viewAL.get(i).toString()+System.getProperty("line.separator"));
	        }
	        fwr.close();
	    } catch (IOException e) {
	        fwr.close();
	        throw e;
	    }
	}
	
	public static void writeBookFile(ArrayList<Booking> bookingAL) throws IOException {
	    FileWriter bookfw = null;
	    
	    try {
	        bookfw = new FileWriter("./data/booking.txt");
	        for(int i=0;i<bookingAL.size();i++) {
	          bookfw.write(bookingAL.get(i).toString()+System.getProperty("line.separator"));
	        }
	        bookfw.close();
	    } catch (IOException e) {
	        bookfw.close();
	        throw e;
	    }
	}
	
	public boolean bookingFitnessLesson(String cId, String bDate, String bDay, String bType,ArrayList<ViewTimeTable> viewAL,ArrayList<Booking> bookingAL) throws Exception
	{
		
		if (bookingAL.isEmpty()) 
		{
			check=true;
		}
		else 
		{
			for(int i=0;i<bookingAL.size();i++)
			{
				if (bookingAL.get(i).getCustId().contains(cId) && bookingAL.get(i).getDate().contains(bDate) && bookingAL.get(i).getDay().equalsIgnoreCase(bDay) && bookingAL.get(i).getType().equalsIgnoreCase(bType)) 
				{
					System.out.println("\n\n\nThis booking already exist !");
					check=false;
				}
				else
				{
					check=true;
				}
			}
		}

		if (check==true) 
		{
			for(int i=0;i<viewAL.size();i++)
			{
				if (viewAL.get(i).getDate().contains(bDate) && viewAL.get(i).getDay().equalsIgnoreCase(bDay) && viewAL.get(i).getType().equalsIgnoreCase(bType) && viewAL.get(i).getCount()<5)
				{
					canBook=true;
					ttId=viewAL.get(i).getId();
					price=viewAL.get(i).getPrice();
					loc=i;
					break;
				}
			}
		}
			
		if (canBook==true) 
		{
			bookfw = new FileWriter("./data/booking.txt", true);
			Booking book=new Booking(ttId,cId,bDate,bDay,bType,price,0,"booked","ok");
			bookingAL.add(book);
			bookfw.write(book.toString()+System.getProperty("line.separator"));
			bookfw.close();
			ViewTimeTable vobj=viewAL.get(loc);
			vobj.setCount(vobj.getCount()+1);
			viewAL.set(loc, vobj);
			writeTimeTableFile("./data/timetable.txt",viewAL);
			System.out.println("\n\n\nYour Booking Successfully...!");
			return true;
		}
		else
		{
			System.out.println("\n\n\nCan not book, booking already complete..");
			return false;
		}
	}
	
	public boolean changeYourBooking(String cId, String bDate, String bDay, String bType, String bDate1, String bDay1, String bType1,ArrayList<ViewTimeTable> viewAL,ArrayList<Booking> bookingAL) throws Exception
	{
		
		if (bookingAL.isEmpty()) 
		{
			check=false;
		}
		else 
		{
			for(int i=0;i<bookingAL.size();i++)
			{
				if (bookingAL.get(i).getCustId().contains(cId) && bookingAL.get(i).getDate().contains(bDate) && bookingAL.get(i).getDay().equalsIgnoreCase(bDay) && bookingAL.get(i).getType().equalsIgnoreCase(bType)) 
				{
					bookLoc=i;
					check=true;
				}
				else
				{
					check=false;
				}
			}
		}

		if (check==true) {
			for(int i=0;i<viewAL.size();i++)
			{
				if (viewAL.get(i).getDate().contains(bDate) && viewAL.get(i).getDay().equalsIgnoreCase(bDay) && viewAL.get(i).getType().equalsIgnoreCase(bType)){
					canChange=true;
					ttId=viewAL.get(i).getId();
					price=viewAL.get(i).getPrice();
					loc=i;
				}
				if (viewAL.get(i).getDate().contains(bDate1) && viewAL.get(i).getDay().equalsIgnoreCase(bDay1) && viewAL.get(i).getType().equalsIgnoreCase(bType1) && viewAL.get(i).getCount()<5){
					canBook=true;
					ttId1=viewAL.get(i).getId();
					price1=viewAL.get(i).getPrice();
					loc1=i;
				}
				if (canChange==true && canBook==true)
					break;
			}
		}
			
		if (canBook==true && canChange==true) {
			bookingAL.remove(bookLoc);
			
			Booking book=new Booking(ttId1,cId,bDate1,bDay1,bType1,price1,0,"changed","ok");
			bookingAL.add(book);
			writeBookFile(bookingAL);
			
			ViewTimeTable vobj=viewAL.get(loc);
			vobj.setCount(vobj.getCount()-1);
			viewAL.set(loc, vobj);
			
			vobj=viewAL.get(loc1);
			vobj.setCount(vobj.getCount()+1);
			viewAL.set(loc1, vobj);
			
			writeTimeTableFile("./data/timetable.txt",viewAL);
			System.out.println("\n\n\nBooking changed successfully");
			return true;
		}
		else
		{
			System.out.println("Can not book, booking already complete or not found..");
			return false;
		}

	}
	
	public boolean cancelYourBooking(String cId, String bDate, String bDay, String bType,ArrayList<ViewTimeTable> viewAL,ArrayList<Booking> bookingAL) throws Exception
	{
		if (bookingAL.isEmpty()) 
		{
			check=false;
		}
		else 
		{
			for(int i=0;i<bookingAL.size();i++)
			{
				if (bookingAL.get(i).getCustId().contains(cId) && bookingAL.get(i).getDate().contains(bDate)) 
				{
					loc=i;
					check=true;
					break;
				}
				else if (bookingAL.get(i).getCustId().contains(cId) && bookingAL.get(i).getDate().contains(bDate) && bookingAL.get(i).getStatus().equalsIgnoreCase("attended"))
				{
					System.out.println("\n\n\nBooking already attended..,can't be cancelled..");
					check=false;
				}
				else 
				{
					check=false;
				}
			}
		}

		if (check==true) 
		{
			for(int i=0;i<viewAL.size();i++)
			{
				if (viewAL.get(i).getDate().contains(bDate) && viewAL.get(i).getDay().equalsIgnoreCase(bDay) && viewAL.get(i).getType().equalsIgnoreCase(bType))
				{
					canCancel=true;
					ttId=viewAL.get(i).getId();
					price=viewAL.get(i).getPrice();
					loc1=i;
					break;
				}
			}
		}

		if (canCancel==true) 
		{
			Booking book=new Booking(ttId,cId,bDate,bDay,bType,price,0,"cancelled","ok");
			bookingAL.remove(loc);
			bookingAL.add(book);
			writeBookFile(bookingAL);
			ViewTimeTable vobj=viewAL.get(loc1);
			vobj.setCount(vobj.getCount()-1);
			viewAL.set(loc1, vobj);
			writeTimeTableFile("./data/timetable.txt",viewAL);
			System.out.println("\n\n\nBooking cancelled successfully");
			return true;
		}
		else
		{
			System.out.println("\n\n\nCan not Cancel");
			return false;
		}
	}
	
	public boolean attendYourBooking(String cId, String bDate, String bDay, String bType, String bReview, int bRate,ArrayList<Booking> bookingAL) throws Exception
	{
		if (bookingAL.isEmpty()) {
			canAttend=false;
		}
		else {
		  for(int i=0;i<bookingAL.size();i++)
		  {
			if (bookingAL.get(i).getCustId().contains(cId) && bookingAL.get(i).getDate().contains(bDate) && bookingAL.get(i).getDay().equalsIgnoreCase(bDay) && bookingAL.get(i).getType().equalsIgnoreCase(bType)) {
				bookLoc=i;
				canAttend=true;
				break;
			}
			else
			{
				canAttend=false;
			}
		 }
		}

			
		if (canAttend==true) {
			Booking book=new Booking(ttId,cId,bDate,bDay,bType,bookingAL.get(bookLoc).getPrice(),bRate,"attended",bReview);
			bookingAL.set(bookLoc,book);
			writeBookFile(bookingAL);
			
	    	System.out.println("Booking attended successfully");
	    	return true;
		}
		else
		{
			System.out.println("Can not book, booking already complete.. or Booking does not exist..");
			return false;
		}
	}
	
	public int monthlyLessonReport(ArrayList<Booking> bookingAL)
	{
		String []type=new String[] {"Saturday","Sunday"};
		int []custCount=new int[2];
		int count=0;
		double []avgRating=new double[2];
		for(int i=0;i<bookingAL.size();i++)
		{
			if (bookingAL.get(i).getDay().equalsIgnoreCase(type[0]) && bookingAL.get(i).getStatus().equalsIgnoreCase("attended")){
				custCount[0]=custCount[0]+1;
				avgRating[0]=avgRating[0]+bookingAL.get(i).getRating();
			}
			else if (bookingAL.get(i).getDay().equalsIgnoreCase(type[1]) && bookingAL.get(i).getStatus().equalsIgnoreCase("attended"))  {
				custCount[1]=custCount[1]+1;
				avgRating[1]=avgRating[1]+bookingAL.get(i).getRating();
			}
		}
		
		System.out.println("\n\t\tMonthly Lesson Report");
		System.out.println("==============================================");
		System.out.println("Day\tNumber Of Customers\tAverage Rating");
		System.out.println("==============================================");
		for(int i=0;i<2;i++) {
			if (custCount[i]>0) {
			avgRating[i]=avgRating[i]/custCount[i];

			System.out.format("%-15s %10d\t%10.3f\n",type[i],custCount[i],avgRating[i]);
			count=count+1;
			}
		}
		System.out.println("=============================================");
		return count;
	}
	
	public int monthlyChampionReport(int month, ArrayList<Booking> bookingAL)
	{
		int mon=0,count=0;
		TreeMap<String,Double> mcfReport=new TreeMap<String,Double>();
		for(int i=0;i<bookingAL.size();i++)
		{
			mon=Integer.parseInt(bookingAL.get(i).getDate().split("-")[1]);
			if (mon==month)
			{
				mcfReport.put(bookingAL.get(i).getType(), bookingAL.get(i).getPrice());
			}
		}
		System.out.println("\n\tMonthly champion fitness type report");
		System.out.println("==============================================");
		System.out.println("Type\t\tIncome");
		System.out.println("==============================================");
		 for(Map.Entry m:mcfReport.entrySet()){    
		       System.out.println(m.getKey()+"\t\t"+m.getValue()); 
		       count=count+1;
		 }    
		System.out.println("=============================================");
		return count;
	}
}
