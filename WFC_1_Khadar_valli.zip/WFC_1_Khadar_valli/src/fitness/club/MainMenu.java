package fitness.club;

public class MainMenu {

	MainMenu()
	{
		System.out.println("\n\n\n======== WELCOME TO WEEKEND FITNESS CLUB ========");
		System.out.println("===================== MENU =====================");
		System.out.println(" 1. Add Customer");
		System.out.println(" 2. Display Customer");
		System.out.println(" 3. View Time Table by Day");
		System.out.println(" 4. View Time Table by Fitness Type");
		System.out.println(" 5. Book a group fitness lesson");
		System.out.println(" 6. Change a booking");
		System.out.println(" 7. Cancel a booking");
		System.out.println(" 8. Attend a lesson");
		System.out.println(" 9. Monthly lesson report");
		System.out.println("10. Monthly champion fitness type report");
		System.out.println(" 0. Exit");
		System.out.println("================================================");
	}
}
